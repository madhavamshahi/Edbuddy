package com.example.edbuddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
